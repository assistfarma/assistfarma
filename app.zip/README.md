# AssistFarma

Simulador inteligente para atendimento farmacêutico.

1. Suba este projeto no GitHub.
2. Faça deploy na Vercel.
3. Configure a variável OPENAI_API_KEY na Vercel.